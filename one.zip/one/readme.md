<!DOCTYPE html>
<html>
<head>
<title>HaanKanWebApplication</title>
<link rel="stylesheet" href="main.css">
</head>
<body>
    <table>
        <img src="https://www.freepnglogos.com/uploads/netflix-logo-circle-png-5.png">
    </table>
</body>
<body>
    <div class="main">
        <div class="img">
            <img src="https://www.freepnglogos.com/uploads/netflix-logo-circle-png-5.png" alt="">
        </div>
    <div class="content">
        <h3>ชื่อ</h3>
        <h3>จำนวนรับ</h3>
        <h3>เรตติ้ง</h3>
        <h3>ราคา</h3>
    </div>
    <div class=" Footer">
        <div class="ft-l">
            <img src="" alt="">
            <p>เข้าร่วม</p>
        </div>
    </div>
    </
</body>
<body>
    <table>
        <div class="name">
            <h2>สวัสดีครับ</h2>
            <h2>สวัสดีครับ</h2>
            <h2>สวัสดีครับ</h2>
        </div>
    </table>
</body>
</html>

<!-- menu -->
<div class="menu" style="height:600px;width:300px;float:left;">
        <h2>ดูรายการทั้งหมด</h2><br>
        <h2>ข่าวประชาสัทพันธ์</h2><br>
        <h2>ดูรายการข้องฉัน</h2><br>
        <h2>ดูรายการที่รออนุมัติ</h2><br>
        <h2>การแจ้งเตือน</h2><br>
        <h2>ตั้งค่า</h2><br>
        <h2>ออกจากระบบ</h2><br>
    </div>
<!-- css -->
.menu{
    background-color: cyan;
    text-align: center;
    height: 500px;
    width:500px;
    display: flex;
    justify-content: center;
    align-items: center;
    flex-direction: column;
}
<!-- ทดลองให้มันแถวตรงกัน -->
<article class="main">
            <div class="img">
                <img src="img/netflix.png" alt="netflix">
            </div>
        <div class="content">
            <h3>ชื่อ "netflix"</h3>
            <h4>จำนวนรับ "3/4"</h4>
            <h4>เรตติ้ง "5ดาว"</h4>
            <h4>ราคา "135 บาท"</h4>
        </div>
        <div class="footer">
            <div class="ft-l">
                <img src="img/netflix2.png" alt="">
                <h4>สมาชิกทั้งหมด</h4>
            </div>
            <div class="ft-r">
                <h4>เข้าร่วม</h4>
        </div>
    </div>
</article>
<article class="main">
    <div class="img">
        <img src="img/netflix.png" alt="netflix">
    </div>
<div class="content">
    <h3>ชื่อ "netflix"</h3>
    <h4>จำนวนรับ "3/4"</h4>
    <h4>เรตติ้ง "5ดาว"</h4>
    <h4>ราคา "135 บาท"</h4>
</div>
<div class="footer">
    <div class="ft-l">
        <img src="img/netflix2.png" alt="">
        <h4>สมาชิกทั้งหมด</h4>
    </div>
    <div class="ft-r">
        <h4>เข้าร่วม</h4>
</div>
</div>
</article>